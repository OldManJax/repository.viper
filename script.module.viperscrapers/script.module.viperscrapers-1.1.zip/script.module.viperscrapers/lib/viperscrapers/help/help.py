# -*- coding: utf-8 -*-
"""
	Viper Scrapers Module
"""

from viperScrapers.modules.control import addonPath, addonVersion, joinPath
from viperScrapers.windows.textviewer import TextViewerXML


def get(file):
	viperScrapers_path = addonPath()
	viperScrapers_version = addonVersion()
	helpFile = joinPath(viperScrapers_path, 'lib', 'viperScrapers', 'help', file + '.txt')
	r = open(helpFile, 'r', encoding='utf-8', errors='ignore')
	text = r.read()
	r.close()
	heading = '[B]Viper Scrapers -  v%s - %s[/B]' % (viperScrapers_version, file)
	windows = TextViewerXML('textviewer.xml', viperScrapers_path, heading=heading, text=text)
	windows.run()
	del windows